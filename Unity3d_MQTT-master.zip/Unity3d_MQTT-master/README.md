Unity3d MQTT
============
[MQTT](http://mqtt.org/) is a machine-to-machine (M2M)/"Internet of Things" connectivity protocol.

[Unity3d](http://unity3d.com/) is a greate platfor for displaying real time stuff in any platform including web. 

therfor combining them together is a great combination. 

Unity3d_MQTT is a small unity3d project showing how to use MQTT protocol.
based on the [M2Mqtt : MQTT client library for Internet of Things & M2M communication](http://code.msdn.microsoft.com/windowsdesktop/M2Mqtt-MQTT-client-library-ac6d3858)

